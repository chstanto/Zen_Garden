/** @file TestTask.h
 *  This file contains a task for adding data for tests
 *  @author  Aaron Tran
 *  @date    2021-Dec-1 Original file
 */

#ifndef _TESTTASK_H
#define _TESTTASK_H

void task_test(void* p_params);

#endif // _TESTTASK_H