/** @file DataTask.cpp
 *    
 * 
 *  @author Cole Stanton
 *  @date   2021-Nov-30 Original file
 */

#include <vector>

class DataClass
{
    protected:
    public:
    void Input_Data(char);
    void Output_Data(void);

};