/** @file DataTask.h
 *    
 * 
 *  @author Cole Stanton
 *  @date   2021-Nov-30 Original file
 */


#ifndef _TASK_DATA_H_
#define _TASK_DATA_H_

void task_data (void* p_params);

#endif // _TASK_DATA_H_